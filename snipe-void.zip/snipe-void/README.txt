Snipe Void (Fabric 1.21.11)
- /snipevoid (lub /sv) otwiera menu
- Void Items: itemy do snajpienia z /void | Sell Items: itemy wkladane do /sell
- Keybind: Activate Menu = klawisz wlaczajacy/wylaczajacy bota
Build:  gradlew build  -> build/libs/snipe-void-1.0.0.jar
Jesli wersje w gradle.properties nie pasuja, skopiuj je z NovaClient.
