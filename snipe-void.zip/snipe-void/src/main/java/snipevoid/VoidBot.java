package snipevoid;

import net.minecraft.block.AbstractChestBlock;
import net.minecraft.block.BarrelBlock;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.ChestBlock;
import net.minecraft.block.enums.ChestType;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ingame.GenericContainerScreen;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.screen.GenericContainerScreenHandler;
import net.minecraft.screen.slot.Slot;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Petla: /void -> snipe -> pelne eq -> (/sell LUB skrzynki) -> /void ...
 * Dziala tylko na itemach z GUI (sloty kontenera), nigdy z ekwipunku gracza.
 */
public class VoidBot {
	private enum State {
		OFF, WAIT_VOID, SNIPING, WAIT_SELL, SELLING, COOLDOWN, WAIT_JOIN,
		CH_CLOSE, CH_OPEN_WAIT, CH_DEPOSIT, CH_DONE, CH_STRAFE, CH_AIM
	}

	private static State state = State.OFF;
	private static int timer = 0;
	private static int page = 0;
	private static int pageWait = 0;
	private static int sellRetries = 0;
	private static int joinTimer = 0;
	private static int waitSellTries = 0;
	private static final int JOIN_DELAY_TICKS = 40; // ~2 s po wejsciu na serwer
	private static final Map<Integer, Integer> recentClicks = new HashMap<>();

	// Układ dolnego rzędu GUI 6x9: 45-47 = cofnij, 51-53 = dalej
	private static final int NEXT_SLOT = 53;

	private static int lastSig = 0;
	private static boolean checkPage = false;
	private static int sameCount = 0;

	// --- tryb skrzynek ---
	private static final Set<BlockPos> fullChests = new HashSet<>();
	private static BlockPos currentChest = null;
	private static BlockPos aimTarget = null;
	private static boolean fallbackMode = false;
	private static int unloadFails = 0;
	private static int openTries = 0;
	private static final int STRAFE_MAX_TICKS = 120; // ~6 s chodzenia w prawo
	private static final double REACH_SQ = 4.5 * 4.5;

	public static boolean isOn() { return state != State.OFF; }

	public static void toggle(MinecraftClient mc) {
		if (isOn()) {
			stop(mc, "§cSnipe Void: OFF");
		} else {
			if (SnipeVoidConfig.INSTANCE.voidItems.isEmpty()) {
				msg(mc, "§eWybierz itemy w menu (/snipevoid) zanim włączysz.");
				return;
			}
			page = 0;
			sellRetries = 0;
			unloadFails = 0;
			fullChests.clear();
			msg(mc, "§aSnipe Void: ON");
			openVoid(mc);
		}
	}

	private static void stop(MinecraftClient mc, String message) {
		state = State.OFF;
		releaseMove(mc);
		msg(mc, message);
	}

	private static void releaseMove(MinecraftClient mc) {
		if (mc.options != null) mc.options.rightKey.setPressed(false);
	}

	private static void msg(MinecraftClient mc, String s) {
		if (mc.player != null) mc.player.sendMessage(Text.literal(s), true);
	}

	private static void openVoid(MinecraftClient mc) {
		mc.getNetworkHandler().sendChatCommand("void");
		state = State.WAIT_VOID;
		timer = 0;
		page = 0;
		pageWait = 0;
		checkPage = false;
		sameCount = 0;
		recentClicks.clear();
	}

	private static void openSell(MinecraftClient mc) {
		mc.getNetworkHandler().sendChatCommand("sell");
		state = State.WAIT_SELL;
		timer = 0;
	}

	/** Pełne eq: /sell albo skrzynki, zależnie od ustawień. */
	private static void startUnload(MinecraftClient mc) {
		if (SnipeVoidConfig.INSTANCE.chestMode) {
			if (mc.currentScreen != null) mc.player.closeHandledScreen();
			state = State.CH_CLOSE;
			timer = 0;
			openTries = 0;
			fallbackMode = false;
			releaseMove(mc);
		} else {
			if (mc.currentScreen != null) mc.player.closeHandledScreen();
			openSell(mc);
		}
	}

	public static void tick(MinecraftClient mc) {
		if (state == State.OFF) return;

		boolean inGame = mc.player != null && mc.world != null
				&& mc.getNetworkHandler() != null && mc.interactionManager != null;
		if (!inGame) {
			if (SnipeVoidConfig.INSTANCE.autoResume) {
				state = State.WAIT_JOIN;
				joinTimer = 0;
			} else {
				state = State.OFF;
			}
			return;
		}
		if (state == State.WAIT_JOIN) {
			if (++joinTimer >= JOIN_DELAY_TICKS) {
				sellRetries = 0;
				waitSellTries = 0;
				unloadFails = 0;
				msg(mc, "§aSnipe Void: wznowiono");
				startUnload(mc);
			}
			return;
		}

		timer++;
		recentClicks.replaceAll((k, v) -> v - 1);
		recentClicks.values().removeIf(v -> v <= 0);

		boolean inContainer = mc.currentScreen instanceof GenericContainerScreen;

		switch (state) {
			case WAIT_VOID -> {
				if (inContainer) { state = State.SNIPING; timer = 0; }
				else if (timer > 60) openVoid(mc);
			}
			case SNIPING -> {
				if (!inContainer) { openVoid(mc); return; }
				snipeTick(mc);
			}
			case WAIT_SELL -> {
				if (inContainer) { state = State.SELLING; timer = 0; waitSellTries = 0; }
				else if (timer > 60) {
					if (++waitSellTries >= 4) { waitSellTries = 0; openVoid(mc); }
					else openSell(mc);
				}
			}
			case SELLING -> {
				if (!inContainer) { openVoid(mc); return; }
				if (timer >= 3) sellTick(mc);
			}
			case COOLDOWN -> {
				if (timer >= 10) {
					if (!hasSpace(mc.player.getInventory()) && hasSellable(mc) && sellRetries < 5) {
						sellRetries++;
						openSell(mc);
					} else {
						sellRetries = 0;
						openVoid(mc);
					}
				}
			}
			case CH_CLOSE -> chestClose(mc);
			case CH_OPEN_WAIT -> chestOpenWait(mc);
			case CH_DEPOSIT -> chestDeposit(mc);
			case CH_DONE -> {
				if (timer >= 4) {
					if (!hasSpace(mc.player.getInventory())) {
						if (++unloadFails >= 3) {
							stop(mc, "§cEq pełne innymi itemami - wyłączam bota.");
							return;
						}
					} else {
						unloadFails = 0;
					}
					openVoid(mc);
				}
			}
			case CH_STRAFE -> chestStrafe(mc);
			case CH_AIM -> chestAim(mc);
			default -> {}
		}
	}

	// ---------------- SNIPE ----------------

	private static void snipeTick(MinecraftClient mc) {
		GenericContainerScreenHandler handler = ((GenericContainerScreen) mc.currentScreen).getScreenHandler();
		PlayerInventory inv = mc.player.getInventory();

		if (pageWait > 0) { pageWait--; return; }

		// po kliknieciu "dalej": sprawdz czy strona sie zmienila (bez stalego czekania)
		if (checkPage) {
			if (pageSig(handler, inv) == lastSig) {
				if (++sameCount >= 15) {
					// ostatnia strona -> zacznij od nowa od strony 1
					mc.player.closeHandledScreen();
					openVoid(mc);
					return;
				}
				pageWait = SnipeVoidConfig.INSTANCE.pageDelayTicks;
				return;
			}
			checkPage = false;
			sameCount = 0;
			page++;
			recentClicks.clear();
		}

		// pelne eq -> sprzedaj / do skrzynek
		if (!hasSpace(inv)) {
			startUnload(mc);
			return;
		}

		SnipeVoidConfig cfg = SnipeVoidConfig.INSTANCE;
		int clicks = 0;
		boolean found = false;
		for (Slot slot : handler.slots) {
			if (slot.inventory == inv) continue; // TYLKO GUI, nie eq
			ItemStack st = slot.getStack();
			if (st.isEmpty() || !isVoidTarget(st)) continue;
			found = true;
			if (recentClicks.containsKey(slot.id)) continue;
			if (!canFit(inv, st)) continue;
			mc.interactionManager.clickSlot(handler.syncId, slot.id, 0, SlotActionType.QUICK_MOVE, mc.player);
			recentClicks.put(slot.id, 4);
			if (++clicks >= cfg.clicksPerTick) break;
		}

		if (clicks == 0 && !found) {
			// nic na tej stronie -> od razu nastepna, i tak do konca; na koncu wraca na strone 1
			lastSig = pageSig(handler, inv);
			checkPage = true;
			sameCount = 0;
			click(mc, handler, NEXT_SLOT);
			pageWait = cfg.pageDelayTicks;
		}
	}

	/** Prosty podpis zawartosci GUI (bez dolnego rzedu z przyciskami). */
	private static int pageSig(GenericContainerScreenHandler handler, PlayerInventory inv) {
		int h = 1;
		for (Slot slot : handler.slots) {
			if (slot.inventory == inv || slot.id >= 45) continue;
			ItemStack st = slot.getStack();
			if (st.isEmpty()) { h = h * 31; continue; }
			h = h * 31 + Registries.ITEM.getId(st.getItem()).hashCode();
			h = h * 31 + st.getCount();
			h = h * 31 + st.getName().getString().hashCode();
		}
		return h;
	}

	private static void click(MinecraftClient mc, GenericContainerScreenHandler h, int slot) {
		mc.interactionManager.clickSlot(h.syncId, slot, 0, SlotActionType.PICKUP, mc.player);
	}

	private static boolean isVoidTarget(ItemStack st) {
		return SnipeVoidConfig.INSTANCE.voidItems.contains(Registries.ITEM.getId(st.getItem()).toString());
	}

	// ---------------- SELL ----------------

	private static void sellTick(MinecraftClient mc) {
		GenericContainerScreenHandler handler = ((GenericContainerScreen) mc.currentScreen).getScreenHandler();
		PlayerInventory inv = mc.player.getInventory();

		int moved = 0;
		for (Slot slot : handler.slots) {
			if (slot.inventory != inv) continue;
			ItemStack st = slot.getStack();
			if (st.isEmpty()) continue;
			if (!SnipeVoidConfig.INSTANCE.sellItems.contains(Registries.ITEM.getId(st.getItem()).toString())) continue;
			mc.interactionManager.clickSlot(handler.syncId, slot.id, 0, SlotActionType.QUICK_MOVE, mc.player);
			if (++moved >= 12) break;
		}

		if (moved == 0) {
			mc.player.closeHandledScreen();
			state = State.COOLDOWN;
			timer = 0;
		}
	}

	private static boolean hasSellable(MinecraftClient mc) {
		PlayerInventory inv = mc.player.getInventory();
		for (int i = 0; i < 36; i++) {
			ItemStack st = inv.getStack(i);
			if (!st.isEmpty() && SnipeVoidConfig.INSTANCE.sellItems.contains(Registries.ITEM.getId(st.getItem()).toString()))
				return true;
		}
		return false;
	}

	// ---------------- SKRZYNKI ----------------

	/** Do skrzynki wkładamy itemy z listy Void oraz z listy Sell. */
	private static boolean isUnloadItem(ItemStack st) {
		String id = Registries.ITEM.getId(st.getItem()).toString();
		return SnipeVoidConfig.INSTANCE.voidItems.contains(id) || SnipeVoidConfig.INSTANCE.sellItems.contains(id);
	}

	private static BlockPos crosshairChest(MinecraftClient mc) {
		if (!(mc.crosshairTarget instanceof BlockHitResult hit)) return null;
		if (hit.getType() != HitResult.Type.BLOCK) return null;
		Block b = mc.world.getBlockState(hit.getBlockPos()).getBlock();
		if (b instanceof AbstractChestBlock<?> || b instanceof BarrelBlock) return hit.getBlockPos().toImmutable();
		return null;
	}

	/** Oznacza skrzynkę jako pełną (razem z drugą połową, jeśli to duża skrzynia). */
	private static void markFull(MinecraftClient mc, BlockPos pos) {
		if (pos == null) return;
		fullChests.add(pos);
		BlockState bs = mc.world.getBlockState(pos);
		if (bs.getBlock() instanceof ChestBlock && bs.contains(ChestBlock.CHEST_TYPE)
				&& bs.get(ChestBlock.CHEST_TYPE) != ChestType.SINGLE) {
			fullChests.add(pos.offset(ChestBlock.getFacing(bs)).toImmutable());
		}
	}

	private static void chestClose(MinecraftClient mc) {
		if (timer < 4) return;                       // chwila na zamkniecie GUI
		if (mc.currentScreen != null) {
			if (timer > 20) mc.player.closeHandledScreen();
			return;
		}
		BlockPos target = crosshairChest(mc);
		if (target != null && (fallbackMode || !fullChests.contains(target))) {
			BlockHitResult hit = (BlockHitResult) mc.crosshairTarget;
			mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND, hit);
			mc.player.swingHand(Hand.MAIN_HAND);
			currentChest = target;
			state = State.CH_OPEN_WAIT;
			timer = 0;
		} else if (target != null) {
			beginStrafe(mc);                         // celownik na pelnej skrzynce -> nastepna
		} else {
			startAim(mc, fallbackMode);              // nie patrzy na skrzynke -> obroc kamere
		}
	}

	private static void chestOpenWait(MinecraftClient mc) {
		if (mc.currentScreen instanceof GenericContainerScreen) {
			state = State.CH_DEPOSIT;
			timer = 0;
			return;
		}
		if (timer > 30) {
			if (++openTries >= 3) {
				markFull(mc, currentChest);
				if (fallbackMode) { stop(mc, "§cNie da się otworzyć skrzynki - wyłączam bota."); return; }
				beginStrafe(mc);
			} else {
				state = State.CH_CLOSE;
				timer = 4;
			}
		}
	}

	private static void chestDeposit(MinecraftClient mc) {
		if (!(mc.currentScreen instanceof GenericContainerScreen gcs)) {
			state = State.CH_CLOSE; // GUI zniknelo
			timer = 0;
			return;
		}
		GenericContainerScreenHandler handler = gcs.getScreenHandler();
		PlayerInventory inv = mc.player.getInventory();

		boolean any = false, fits = false;
		int moved = 0;
		for (Slot slot : handler.slots) {
			if (slot.inventory != inv) continue; // tylko z eq gracza
			ItemStack st = slot.getStack();
			if (st.isEmpty() || !isUnloadItem(st)) continue;
			any = true;
			if (!chestCanFit(handler, inv, st)) continue;
			fits = true;
			if (recentClicks.containsKey(slot.id)) continue;
			if (moved >= 12) continue;
			mc.interactionManager.clickSlot(handler.syncId, slot.id, 0, SlotActionType.QUICK_MOVE, mc.player);
			recentClicks.put(slot.id, 3);
			moved++;
		}

		if (!any) {
			// wszystko wlozone
			mc.player.closeHandledScreen();
			state = State.CH_DONE;
			timer = 0;
		} else if (!fits || timer > 80) {
			// skrzynka pelna
			markFull(mc, currentChest);
			mc.player.closeHandledScreen();
			if (fallbackMode) {
				stop(mc, "§cSkrzynki są pełne - wyłączam bota.");
			} else {
				beginStrafe(mc);
			}
		}
	}

	private static boolean chestCanFit(GenericContainerScreenHandler handler, PlayerInventory inv, ItemStack st) {
		for (Slot slot : handler.slots) {
			if (slot.inventory == inv) continue;
			ItemStack s = slot.getStack();
			if (s.isEmpty()) return true;
			if (ItemStack.areItemsAndComponentsEqual(s, st) && s.getCount() < s.getMaxCount()) return true;
		}
		return false;
	}

	private static void beginStrafe(MinecraftClient mc) {
		state = State.CH_STRAFE;
		timer = 0;
		openTries = 0;
	}

	/** Idzie w prawo (bez teleportu), aż celownik trafi w kolejną niepełną skrzynkę. */
	private static void chestStrafe(MinecraftClient mc) {
		if (mc.currentScreen != null) {
			mc.player.closeHandledScreen();
			return;
		}
		mc.options.rightKey.setPressed(true);
		BlockPos t = crosshairChest(mc);
		if (timer > 3 && t != null && !fullChests.contains(t)) {
			releaseMove(mc);
			state = State.CH_CLOSE;
			timer = 4;
			openTries = 0;
			return;
		}
		if (timer > STRAFE_MAX_TICKS) {
			// skrzynki sie skonczyly
			releaseMove(mc);
			startAim(mc, true);
		}
	}

	/** Szuka skrzynki w zasięgu najbliżej "środka" skrzynek. */
	private static BlockPos findCenterChest(MinecraftClient mc) {
		Vec3d eye = mc.player.getEyePos();
		BlockPos base = mc.player.getBlockPos();
		List<BlockPos> found = new ArrayList<>();
		for (BlockPos p : BlockPos.iterate(base.add(-5, -4, -5), base.add(5, 4, 5))) {
			Block b = mc.world.getBlockState(p).getBlock();
			if (!(b instanceof AbstractChestBlock<?> || b instanceof BarrelBlock)) continue;
			if (eye.squaredDistanceTo(Vec3d.ofCenter(p)) > REACH_SQ) continue;
			found.add(p.toImmutable());
		}
		if (found.isEmpty()) return null;
		double cx = 0, cy = 0, cz = 0;
		for (BlockPos p : found) { cx += p.getX(); cy += p.getY(); cz += p.getZ(); }
		cx /= found.size(); cy /= found.size(); cz /= found.size();
		BlockPos best = null;
		double bd = Double.MAX_VALUE;
		for (BlockPos p : found) {
			double dx = p.getX() - cx, dy = p.getY() - cy, dz = p.getZ() - cz;
			double d = dx * dx + dy * dy + dz * dz;
			if (d < bd) { bd = d; best = p; }
		}
		return best;
	}

	private static void startAim(MinecraftClient mc, boolean fallback) {
		BlockPos best = findCenterChest(mc);
		if (best == null) {
			stop(mc, "§cBrak skrzynki w zasięgu - wyłączam bota.");
			return;
		}
		aimTarget = best;
		fallbackMode = fallback;
		state = State.CH_AIM;
		timer = 0;
	}

	/** Płynny obrót kamery (max kilka stopni na tick) na wybraną skrzynkę - bez teleportu. */
	private static void chestAim(MinecraftClient mc) {
		if (mc.currentScreen != null) {
			mc.player.closeHandledScreen();
			return;
		}
		Vec3d eye = mc.player.getEyePos();
		Vec3d c = Vec3d.ofCenter(aimTarget);
		double dx = c.x - eye.x, dy = c.y - eye.y, dz = c.z - eye.z;
		float targetYaw = (float) Math.toDegrees(Math.atan2(dz, dx)) - 90f;
		float targetPitch = (float) -Math.toDegrees(Math.atan2(dy, Math.sqrt(dx * dx + dz * dz)));

		float dYaw = MathHelper.wrapDegrees(targetYaw - mc.player.getYaw());
		float dPitch = targetPitch - mc.player.getPitch();
		float step = 8f;
		mc.player.setYaw(mc.player.getYaw() + MathHelper.clamp(dYaw, -step, step));
		mc.player.setPitch(MathHelper.clamp(mc.player.getPitch() + MathHelper.clamp(dPitch, -step, step), -90f, 90f));

		BlockPos t = crosshairChest(mc);
		if (t != null && (Math.abs(dYaw) < 2f && Math.abs(dPitch) < 2f || t.equals(aimTarget))) {
			state = State.CH_CLOSE;
			timer = 4;
			openTries = 0;
			return;
		}
		if (timer > 100) stop(mc, "§cNie udało się wycelować w skrzynkę - wyłączam bota.");
	}

	// ---------------- EQ ----------------

	private static boolean hasSpace(PlayerInventory inv) {
		for (int i = 0; i < 36; i++) if (inv.getStack(i).isEmpty()) return true;
		return false;
	}

	private static boolean canFit(PlayerInventory inv, ItemStack st) {
		for (int i = 0; i < 36; i++) {
			ItemStack s = inv.getStack(i);
			if (s.isEmpty()) return true;
			if (ItemStack.areItemsAndComponentsEqual(s, st) && s.getCount() < s.getMaxCount()) return true;
		}
		return false;
	}
}
