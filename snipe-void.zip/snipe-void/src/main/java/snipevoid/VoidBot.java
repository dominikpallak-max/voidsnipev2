package snipevoid;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ingame.GenericContainerScreen;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.screen.GenericContainerScreenHandler;
import net.minecraft.screen.slot.Slot;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.text.Text;

import java.util.HashMap;
import java.util.Map;

/**
 * Petla: /void -> snipe -> pelne eq -> /sell -> wkladanie -> zamkniecie -> /void ...
 * Dziala tylko na itemach z GUI (sloty kontenera), nigdy z ekwipunku gracza.
 */
public class VoidBot {
	private enum State { OFF, WAIT_VOID, SNIPING, WAIT_SELL, SELLING, COOLDOWN, DOUBLE_WAIT, DOUBLE_DONE, WAIT_JOIN }

	private static State state = State.OFF;
	private static int timer = 0;      // licznik ticków dla timeoutów / opóźnień
	private static int page = 0;       // 0 = strona 1, 1 = strona 2
	private static int pageWait = 0;   // czekanie po kliknieciu zmiany strony
	private static int sellRetries = 0;
	private static final Map<Integer, Integer> recentClicks = new HashMap<>();

	// Układ dolnego rzędu GUI 6x9: 45-47 = cofnij (3 przyciski), 51-53 = dalej (3 przyciski)
	private static final int BACK_SLOT = 45;
	private static final int NEXT_SLOT = 53;
	private static int lastSig = 0;        // podpis zawartości strony przed kliknięciem "dalej"
	private static boolean checkPage = false;
	private static int sameCount = 0;
	private static int joinTimer = 0;
	private static int waitSellTries = 0;
	private static final int JOIN_DELAY_TICKS = 40; // ~2 s po wejściu na serwer
	private static int dcSlot = 0;
	private static int dcTimer = 0;

	public static boolean isOn() { return state != State.OFF; }

	public static void toggle(MinecraftClient mc) {
		if (isOn()) {
			state = State.OFF;
			msg(mc, "§cSnipe Void: OFF");
		} else {
			if (SnipeVoidConfig.INSTANCE.voidItems.isEmpty()) {
				msg(mc, "§eWybierz itemy w menu (/snipevoid) zanim włączysz.");
				return;
			}
			page = 0;
			sellRetries = 0;
			msg(mc, "§aSnipe Void: ON");
			openVoid(mc);
		}
	}

	private static void msg(MinecraftClient mc, String s) {
		if (mc.player != null) mc.player.sendMessage(Text.literal(s), true);
	}

	private static void openVoid(MinecraftClient mc) {
		mc.getNetworkHandler().sendChatCommand("void");
		state = State.WAIT_VOID;
		timer = 0;
		page = 0;
		pageWait = 0;
		checkPage = false;
		sameCount = 0;
		recentClicks.clear();
	}

	private static void openSell(MinecraftClient mc) {
		mc.getNetworkHandler().sendChatCommand("sell");
		state = State.WAIT_SELL;
		timer = 0;
	}

	public static void tick(MinecraftClient mc) {
		if (state == State.OFF) return;
		boolean inGame = mc.player != null && mc.world != null
				&& mc.getNetworkHandler() != null && mc.interactionManager != null;
		if (!inGame) {
			// wyrzucony / rozłączony: zostaw bota włączonego i czekaj na ponowne wejście
			if (SnipeVoidConfig.INSTANCE.autoResume) {
				state = State.WAIT_JOIN;
				joinTimer = 0;
			} else {
				state = State.OFF;
			}
			return;
		}
		if (state == State.WAIT_JOIN) {
			// po wejściu: chwila na załadowanie, potem od razu /sell i sprzedaż
			if (++joinTimer >= JOIN_DELAY_TICKS) {
				sellRetries = 0;
				waitSellTries = 0;
				msg(mc, "§aSnipe Void: wznowiono - /sell");
				openSell(mc);
			}
			return;
		}
		timer++;
		recentClicks.replaceAll((k, v) -> v - 1);
		recentClicks.values().removeIf(v -> v <= 0);

		boolean inContainer = mc.currentScreen instanceof GenericContainerScreen;

		switch (state) {
			case WAIT_VOID -> {
				if (inContainer) { state = State.SNIPING; timer = 0; }
				else if (timer > 60) openVoid(mc); // ponów komendę
			}
			case SNIPING -> {
				if (!inContainer) { // serwer zamknął GUI -> otwórz ponownie
					openVoid(mc);
					return;
				}
				snipeTick(mc);
			}
			case WAIT_SELL -> {
				if (inContainer) { state = State.SELLING; timer = 0; waitSellTries = 0; }
				else if (timer > 60) {
					// /sell nie otworzyło GUI - ponów kilka razy, potem wróć do /void
					if (++waitSellTries >= 4) { waitSellTries = 0; openVoid(mc); }
					else openSell(mc);
				}
			}
			case SELLING -> {
				if (!inContainer) { openVoid(mc); return; }
				if (timer >= 3) sellTick(mc);
			}
			case DOUBLE_WAIT -> {
				// tryb shift + 2 kliki: drugie kliknięcie na ten sam slot
				if (--dcTimer <= 0) {
					var h = mc.player.currentScreenHandler;
					mc.interactionManager.clickSlot(h.syncId, dcSlot, 0, SlotActionType.QUICK_MOVE, mc.player);
					state = State.DOUBLE_DONE;
					dcTimer = 4;
				}
			}
			case DOUBLE_DONE -> {
				// wyjście z GUI i sprzedaż
				if (--dcTimer <= 0) {
					if (mc.currentScreen != null) mc.player.closeHandledScreen();
					openSell(mc);
				}
			}
			case COOLDOWN -> {
				if (timer >= 10) {
					if (!hasSpace(mc.player.getInventory()) && hasSellable(mc) && sellRetries < 5) {
						sellRetries++;
						openSell(mc);
					} else {
						sellRetries = 0;
						openVoid(mc);
					}
				}
			}
			default -> {}
		}
	}

	// ---------------- SNIPE ----------------

	private static void snipeTick(MinecraftClient mc) {
		GenericContainerScreenHandler handler = ((GenericContainerScreen) mc.currentScreen).getScreenHandler();
		PlayerInventory inv = mc.player.getInventory();

		if (pageWait > 0) { pageWait--; return; }

		// po kliknięciu "dalej": sprawdź czy strona faktycznie się zmieniła
		if (checkPage) {
			if (pageSig(handler, inv) == lastSig) {
				if (++sameCount >= 5) {
					// ostatnia strona -> zacznij od nowa od strony 1
					mc.player.closeHandledScreen();
					openVoid(mc);
					return;
				}
				pageWait = Math.max(1, SnipeVoidConfig.INSTANCE.pageDelay);
				return;
			}
			checkPage = false;
			sameCount = 0;
			page++;
			recentClicks.clear();
		}

		// pełne eq -> sprzedaj
		if (!hasSpace(inv)) {
			mc.player.closeHandledScreen();
			openSell(mc);
			return;
		}

		SnipeVoidConfig cfg = SnipeVoidConfig.INSTANCE;
		int clicks = 0;
		boolean found = false;

		if (cfg.shiftDoubleMode) {
			for (Slot slot : handler.slots) {
				if (slot.inventory == inv) continue; // TYLKO GUI
				ItemStack st = slot.getStack();
				if (st.isEmpty() || !isVoidTarget(st)) continue;
				found = true;
				if (!canFit(inv, st)) continue;
				// shift + klik (QUICK_MOVE), potem po chwili drugi klik na ten slot
				mc.interactionManager.clickSlot(handler.syncId, slot.id, 0, SlotActionType.QUICK_MOVE, mc.player);
				dcSlot = slot.id;
				dcTimer = Math.max(1, cfg.doubleClickDelay);
				state = State.DOUBLE_WAIT;
				return;
			}
		}

		if (!cfg.shiftDoubleMode) for (Slot slot : handler.slots) {
			if (slot.inventory == inv) continue; // TYLKO GUI, nie eq
			ItemStack st = slot.getStack();
			if (st.isEmpty() || !isVoidTarget(st)) continue;
			found = true;
			if (recentClicks.containsKey(slot.id)) continue;
			if (!canFit(inv, st)) continue;
			mc.interactionManager.clickSlot(handler.syncId, slot.id, 0, SlotActionType.QUICK_MOVE, mc.player);
			recentClicks.put(slot.id, 4);
			if (++clicks >= SnipeVoidConfig.INSTANCE.clicksPerTick) break;
		}

		if (clicks == 0 && !found) {
			// nic na tej stronie -> następna, i tak aż do końca; na końcu wraca na stronę 1
			lastSig = pageSig(handler, inv);
			checkPage = true;
			sameCount = 0;
			click(mc, handler, NEXT_SLOT);
			pageWait = Math.max(1, SnipeVoidConfig.INSTANCE.pageDelay);
		}
	}

	/** Prosty podpis zawartości GUI (bez dolnego rzędu z przyciskami). */
	private static int pageSig(GenericContainerScreenHandler handler, PlayerInventory inv) {
		int h = 1;
		for (Slot slot : handler.slots) {
			if (slot.inventory == inv || slot.id >= 45) continue;
			ItemStack st = slot.getStack();
			if (st.isEmpty()) { h = h * 31; continue; }
			h = h * 31 + Registries.ITEM.getId(st.getItem()).hashCode();
			h = h * 31 + st.getCount();
			h = h * 31 + st.getName().getString().hashCode();
		}
		return h;
	}

	private static void click(MinecraftClient mc, GenericContainerScreenHandler h, int slot) {
		mc.interactionManager.clickSlot(h.syncId, slot, 0, SlotActionType.PICKUP, mc.player);
	}

	private static boolean isVoidTarget(ItemStack st) {
		return SnipeVoidConfig.INSTANCE.voidItems.contains(Registries.ITEM.getId(st.getItem()).toString());
	}

	// ---------------- SELL ----------------

	private static void sellTick(MinecraftClient mc) {
		GenericContainerScreenHandler handler = ((GenericContainerScreen) mc.currentScreen).getScreenHandler();
		PlayerInventory inv = mc.player.getInventory();

		int moved = 0;
		for (Slot slot : handler.slots) {
			if (slot.inventory != inv) continue; // tylko sloty gracza -> do GUI sell
			ItemStack st = slot.getStack();
			if (st.isEmpty()) continue;
			if (!SnipeVoidConfig.INSTANCE.sellItems.contains(Registries.ITEM.getId(st.getItem()).toString())) continue;
			mc.interactionManager.clickSlot(handler.syncId, slot.id, 0, SlotActionType.QUICK_MOVE, mc.player);
			if (++moved >= 12) break; // wiele na tick, ale z limitem
		}

		if (moved == 0) {
			// nic więcej do wkładania -> zamknij (sprzedaż po zamknięciu) i wróć do /void
			mc.player.closeHandledScreen();
			state = State.COOLDOWN;
			timer = 0;
		}
	}

	private static boolean hasSellable(MinecraftClient mc) {
		PlayerInventory inv = mc.player.getInventory();
		for (int i = 0; i < 36; i++) {
			ItemStack st = inv.getStack(i);
			if (!st.isEmpty() && SnipeVoidConfig.INSTANCE.sellItems.contains(Registries.ITEM.getId(st.getItem()).toString()))
				return true;
		}
		return false;
	}

	// ---------------- EQ ----------------

	/** Czy jest w ogóle wolny slot (hotbar + główne 36). */
	private static boolean hasSpace(PlayerInventory inv) {
		for (int i = 0; i < 36; i++) if (inv.getStack(i).isEmpty()) return true;
		return false;
	}

	/** Czy ten stack zmieści się w eq (wolny slot lub dopełnienie stacka). */
	private static boolean canFit(PlayerInventory inv, ItemStack st) {
		for (int i = 0; i < 36; i++) {
			ItemStack s = inv.getStack(i);
			if (s.isEmpty()) return true;
			if (ItemStack.areItemsAndComponentsEqual(s, st) && s.getCount() < s.getMaxCount()) return true;
		}
		return false;
	}
}
