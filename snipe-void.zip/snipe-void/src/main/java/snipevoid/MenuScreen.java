package snipevoid;

import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.client.input.KeyInput;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

public class MenuScreen extends Screen {
	private enum Tab { VOID, SELL, KEYBIND, SETTINGS }

	private static final int CELL = 20;
	private Tab tab = Tab.VOID;
	private TextFieldWidget search;
	private String query = "";
	private int scroll = 0;
	private boolean listening = false;

	private final List<ItemStack> allStacks = new ArrayList<>();
	private List<ItemStack> shown = new ArrayList<>();

	private int gridX, gridY, cols, rows;

	public MenuScreen() {
		super(Text.literal("Snipe Void"));
		for (Item item : Registries.ITEM) {
			ItemStack st = new ItemStack(item);
			if (!st.isEmpty()) allStacks.add(st);
		}
	}

	@Override
	protected void init() {
		int tabW = 80;
		int startX = width / 2 - (tabW * 4 + 12) / 2;
		addDrawableChild(ButtonWidget.builder(Text.literal("Void Items"), b -> switchTab(Tab.VOID))
				.dimensions(startX, 10, tabW, 20).build());
		addDrawableChild(ButtonWidget.builder(Text.literal("Sell / Chest"), b -> switchTab(Tab.SELL))
				.dimensions(startX + tabW + 4, 10, tabW, 20).build());
		addDrawableChild(ButtonWidget.builder(Text.literal("Keybind"), b -> switchTab(Tab.KEYBIND))
				.dimensions(startX + (tabW + 4) * 2, 10, tabW, 20).build());
		addDrawableChild(ButtonWidget.builder(Text.literal("Ustawienia"), b -> switchTab(Tab.SETTINGS))
				.dimensions(startX + (tabW + 4) * 3, 10, tabW, 20).build());

		if (tab == Tab.KEYBIND) {
			addDrawableChild(ButtonWidget.builder(keyButtonText(), b -> {
				listening = true;
				b.setMessage(Text.literal("> Wciśnij klawisz <"));
			}).dimensions(width / 2 - 100, 70, 200, 20).build());
		} else if (tab == Tab.SETTINGS) {
			SnipeVoidConfig c = SnipeVoidConfig.INSTANCE;
			int bx = width / 2 - 130;

			addDrawableChild(ButtonWidget.builder(modeText(), b -> {
				c.chestMode = !c.chestMode;
				b.setMessage(modeText());
			}).dimensions(bx, 60, 260, 20).build());

			addDrawableChild(ButtonWidget.builder(Text.literal("Kliknięć na tick (tryb szybki): " + c.clicksPerTick), b -> {
				c.clicksPerTick = c.clicksPerTick >= 10 ? 1 : c.clicksPerTick + 1;
				b.setMessage(Text.literal("Kliknięć na tick (tryb szybki): " + c.clicksPerTick));
			}).dimensions(bx, 90, 260, 20).build());

			addDrawableChild(ButtonWidget.builder(pageText(), b -> {
				c.pageDelayTicks = c.pageDelayTicks >= 10 ? 0 : c.pageDelayTicks + 1;
				b.setMessage(pageText());
			}).dimensions(bx, 120, 260, 20).build());

			addDrawableChild(ButtonWidget.builder(resumeText(), b -> {
				c.autoResume = !c.autoResume;
				b.setMessage(resumeText());
			}).dimensions(bx, 150, 260, 20).build());
		} else {
			search = new TextFieldWidget(textRenderer, width / 2 - 100, 36, 200, 18, Text.literal("Search"));
			search.setText(query);
			search.setPlaceholder(Text.literal("Szukaj itemu..."));
			search.setChangedListener(s -> { query = s; scroll = 0; refilter(); });
			addDrawableChild(search);

			addDrawableChild(ButtonWidget.builder(Text.literal("Clear"), b -> selection().clear())
					.dimensions(width - 60, 36, 50, 18).build());

			gridX = 20;
			gridY = 62;
			cols = Math.max(1, (width - 40) / CELL);
			rows = Math.max(1, (height - gridY - 20) / CELL);
			refilter();
		}
	}

	private Text modeText() {
		return Text.literal(SnipeVoidConfig.INSTANCE.chestMode
				? "Gdy pełne eq: do skrzynek (bez /sell)"
				: "Gdy pełne eq: /sell");
	}

	private Text resumeText() {
		return Text.literal("Wznów po wyrzuceniu z serwera (/sell): "
				+ (SnipeVoidConfig.INSTANCE.autoResume ? "ON" : "OFF"));
	}

	private Text pageText() {
		int d = SnipeVoidConfig.INSTANCE.pageDelayTicks;
		return Text.literal("Opóźnienie zmiany strony: " + (d == 0 ? "0 (max szybkość)" : d + " tick"));
	}

	private boolean isItemTab() { return tab == Tab.VOID || tab == Tab.SELL; }

	private Text keyButtonText() {
		KeyBinding kb = SnipeVoidClient.activateKey;
		return Text.literal("Activate Menu: ").append(kb.getBoundKeyLocalizedText());
	}

	private void switchTab(Tab t) {
		tab = t;
		scroll = 0;
		listening = false;
		clearAndInit();
	}

	private Set<String> selection() {
		return tab == Tab.VOID ? SnipeVoidConfig.INSTANCE.voidItems : SnipeVoidConfig.INSTANCE.sellItems;
	}

	private void refilter() {
		String q = query.toLowerCase().trim();
		shown = new ArrayList<>();
		for (ItemStack st : allStacks) {
			if (q.isEmpty()
					|| st.getName().getString().toLowerCase().contains(q)
					|| Registries.ITEM.getId(st.getItem()).getPath().contains(q)) {
				shown.add(st);
			}
		}
	}

	private String idOf(ItemStack st) {
		return Registries.ITEM.getId(st.getItem()).toString();
	}

	@Override
	public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
		super.render(ctx, mouseX, mouseY, delta);

		ctx.drawCenteredTextWithShadow(textRenderer, Text.literal("§lSnipe Void"), width / 2, 0 + 1, 0xFFFFFFFF);

		if (tab == Tab.SETTINGS) {
			ctx.drawCenteredTextWithShadow(textRenderer,
					Text.literal("Opóźnienie 0 = najszybciej. Zwiększ, jeśli serwer gubi kliknięcia."),
					width / 2, 40, 0xFFAAAAAA);
			ctx.drawCenteredTextWithShadow(textRenderer,
					Text.literal("Tryb skrzynek: stój przodem do skrzynki (celownik na niej), mod idzie w prawo do kolejnych."),
					width / 2, 185, 0xFF888888);
			ctx.drawCenteredTextWithShadow(textRenderer,
					Text.literal("Do skrzynek idą itemy z list Void i Sell / Chest."),
					width / 2, 197, 0xFF888888);
			return;
		}

		if (tab == Tab.KEYBIND) {
			ctx.drawCenteredTextWithShadow(textRenderer,
					Text.literal("Ten klawisz włącza/wyłącza bota (wpisze /void i zacznie snajpić)."),
					width / 2, 50, 0xFFAAAAAA);
			ctx.drawCenteredTextWithShadow(textRenderer,
					Text.literal("Backspace = usuń przypisanie, Esc = anuluj."), width / 2, 130, 0xFF888888);
			return;
		}

		Set<String> sel = selection();
		ctx.drawTextWithShadow(textRenderer, Text.literal("Wybrane: " + sel.size()), 20, 40, 0xFF55FF55);

		int maxScroll = Math.max(0, (int) Math.ceil(shown.size() / (double) cols) - rows);
		scroll = Math.max(0, Math.min(scroll, maxScroll));

		ItemStack hovered = null;
		for (int r = 0; r < rows; r++) {
			for (int c = 0; c < cols; c++) {
				int idx = (r + scroll) * cols + c;
				if (idx >= shown.size()) break;
				ItemStack st = shown.get(idx);
				int x = gridX + c * CELL;
				int y = gridY + r * CELL;
				boolean on = sel.contains(idDirect(st));
				ctx.fill(x, y, x + CELL - 2, y + CELL - 2, on ? 0xAA00B000 : 0x55000000);
				ctx.drawItem(st, x + 1, y + 1);
				if (mouseX >= x && mouseX < x + CELL - 2 && mouseY >= y && mouseY < y + CELL - 2) hovered = st;
			}
		}
		if (hovered != null) ctx.drawItemTooltip(textRenderer, hovered, mouseX, mouseY);
	}

	private String idDirect(ItemStack st) { return idOf(st); }

	@Override
	public boolean mouseClicked(Click click, boolean doubled) {
		if (super.mouseClicked(click, doubled)) return true;
		if (!isItemTab()) return false;

		double mx = click.x(), my = click.y();
		int c = (int) ((mx - gridX) / CELL);
		int r = (int) ((my - gridY) / CELL);
		if (mx < gridX || my < gridY || c < 0 || c >= cols || r < 0 || r >= rows) return false;
		int idx = (r + scroll) * cols + c;
		if (idx >= shown.size()) return false;

		String id = idOf(shown.get(idx));
		Set<String> sel = selection();
		if (!sel.remove(id)) sel.add(id);
		return true;
	}

	@Override
	public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
		if (isItemTab()) {
			scroll -= (int) Math.signum(verticalAmount) * 2;
			return true;
		}
		return super.mouseScrolled(mouseX, mouseY, horizontalAmount, verticalAmount);
	}

	@Override
	public boolean keyPressed(KeyInput input) {
		if (listening) {
			int key = input.key();
			listening = false;
			if (key != GLFW.GLFW_KEY_ESCAPE) {
				InputUtil.Key bound = (key == GLFW.GLFW_KEY_BACKSPACE)
						? InputUtil.UNKNOWN_KEY
						: InputUtil.Type.KEYSYM.createFromCode(key);
				SnipeVoidClient.activateKey.setBoundKey(bound);
				KeyBinding.updateKeysByCode();
				client.options.write();
			}
			clearAndInit();
			return true;
		}
		return super.keyPressed(input);
	}

	@Override
	public void removed() {
		SnipeVoidConfig.save();
	}

	@Override
	public boolean shouldPause() {
		return false;
	}
}
