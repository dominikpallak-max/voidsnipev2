package snipevoid;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

public class SnipeVoidClient implements ClientModInitializer {
	public static KeyBinding activateKey;
	private static boolean pendingOpenMenu = false;

	@Override
	public void onInitializeClient() {
		SnipeVoidConfig.load();

		KeyBinding.Category category = KeyBinding.Category.create(Identifier.of("snipevoid", "main"));
		activateKey = KeyBindingHelper.registerKeyBinding(
				new KeyBinding("key.snipevoid.activate", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_UNKNOWN, category));

		// /snipevoid  (alias /sv) otwiera menu
		ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) -> {
			var node = dispatcher.register(ClientCommandManager.literal("snipevoid").executes(ctx -> {
				pendingOpenMenu = true;
				return 1;
			}));
			dispatcher.register(ClientCommandManager.literal("sv").redirect(node));
		});

		ClientTickEvents.END_CLIENT_TICK.register(client -> {
			if (pendingOpenMenu && client.currentScreen == null) {
				pendingOpenMenu = false;
				client.setScreen(new MenuScreen());
			}
			while (activateKey.wasPressed()) {
				if (client.currentScreen == null && client.player != null) VoidBot.toggle(client);
			}
			VoidBot.tick(client);
		});
	}
}
