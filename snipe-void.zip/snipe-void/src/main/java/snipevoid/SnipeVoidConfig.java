package snipevoid;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedHashSet;
import java.util.Set;

public class SnipeVoidConfig {
	private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
	private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("snipevoid.json");
	public static SnipeVoidConfig INSTANCE = new SnipeVoidConfig();

	/** ID itemow do snajpienia z /void, np. minecraft:kelp */
	public Set<String> voidItems = new LinkedHashSet<>();
	/** ID itemow do wlozenia do /sell */
	public Set<String> sellItems = new LinkedHashSet<>();
	/** Ile klikniec na tick (szybkosc zbierania) */
	public int clicksPerTick = 4;
	/** false = po pełnym eq /sell; true = odkładanie do skrzynek (celownik na skrzynce) */
	public boolean chestMode = false;
	/** Opóźnienie (ticki) po kliknięciu "następna strona"; 0 = bez opóźnienia */
	public int pageDelayTicks = 0;
	/** Po wyrzuceniu z serwera bot zostaje włączony, a po wejściu od razu robi /sell */
	public boolean autoResume = true;

	public static void load() {
		try {
			if (Files.exists(FILE)) {
				SnipeVoidConfig c = GSON.fromJson(Files.readString(FILE), SnipeVoidConfig.class);
				if (c != null) {
					if (c.voidItems == null) c.voidItems = new LinkedHashSet<>();
					if (c.sellItems == null) c.sellItems = new LinkedHashSet<>();
					INSTANCE = c;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void save() {
		try {
			Files.writeString(FILE, GSON.toJson(INSTANCE));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
